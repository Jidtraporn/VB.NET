﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.student_id = New System.Windows.Forms.Label()
        Me.student_name = New System.Windows.Forms.Label()
        Me.student_email = New System.Windows.Forms.Label()
        Me.student_age = New System.Windows.Forms.Label()
        Me.student_enroll = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(35, 38)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(205, 66)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "รายงานข้อมูลนักศึกษา"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'student_id
        '
        Me.student_id.AutoSize = True
        Me.student_id.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.student_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.student_id.Location = New System.Drawing.Point(35, 117)
        Me.student_id.Name = "student_id"
        Me.student_id.Size = New System.Drawing.Size(87, 22)
        Me.student_id.TabIndex = 1
        Me.student_id.Text = "รหัสนักศึกษา"
        '
        'student_name
        '
        Me.student_name.AutoSize = True
        Me.student_name.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.student_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.student_name.Location = New System.Drawing.Point(35, 153)
        Me.student_name.Name = "student_name"
        Me.student_name.Size = New System.Drawing.Size(80, 22)
        Me.student_name.TabIndex = 2
        Me.student_name.Text = "ชื่อนักศึกษา"
        '
        'student_email
        '
        Me.student_email.AutoSize = True
        Me.student_email.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.student_email.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.student_email.Location = New System.Drawing.Point(35, 186)
        Me.student_email.Name = "student_email"
        Me.student_email.Size = New System.Drawing.Size(95, 22)
        Me.student_email.TabIndex = 3
        Me.student_email.Text = "อีเมล์นักศึกษา"
        '
        'student_age
        '
        Me.student_age.AutoSize = True
        Me.student_age.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.student_age.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.student_age.Location = New System.Drawing.Point(35, 220)
        Me.student_age.Name = "student_age"
        Me.student_age.Size = New System.Drawing.Size(86, 22)
        Me.student_age.TabIndex = 4
        Me.student_age.Text = "อายุนักศึกษา"
        '
        'student_enroll
        '
        Me.student_enroll.AutoSize = True
        Me.student_enroll.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.student_enroll.Location = New System.Drawing.Point(31, 257)
        Me.student_enroll.Name = "student_enroll"
        Me.student_enroll.Size = New System.Drawing.Size(173, 20)
        Me.student_enroll.TabIndex = 5
        Me.student_enroll.Text = "ค่าลงทะเบียนตลอดหลักสูตร"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 300)
        Me.Controls.Add(Me.student_enroll)
        Me.Controls.Add(Me.student_age)
        Me.Controls.Add(Me.student_email)
        Me.Controls.Add(Me.student_name)
        Me.Controls.Add(Me.student_id)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents student_id As System.Windows.Forms.Label
    Friend WithEvents student_name As System.Windows.Forms.Label
    Friend WithEvents student_email As System.Windows.Forms.Label
    Friend WithEvents student_age As System.Windows.Forms.Label
    Friend WithEvents student_enroll As System.Windows.Forms.Label

End Class
