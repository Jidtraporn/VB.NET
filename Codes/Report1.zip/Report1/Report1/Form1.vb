﻿Option Explicit Off
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        student_id.Text = "634272103"
        student_name.Text = "Jitarporn Tongoon"
        student_email.Text = "jitarporn.tho@mail.pbru.ac.th"

        Dim birthdate As Date = #5/19/2002#

        REM Dim age As Integer

        age = Year(Today()) - Year(birthdate)
        dw = birthdate.DayofWeek
        student_age.Text = age.ToString & " เกิดวัน " & birthdate.ToString("dddd")
        student_enroll.Text = (16000 * 8).ToString("฿#,###")
    End Sub

End Class
